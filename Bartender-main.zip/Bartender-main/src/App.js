import CocktailWrapper from "./Cocktails/CocktailWrapper";

function App() {
  return (
    <div>
      <CocktailWrapper />
    </div>
  );
}

export default App;
